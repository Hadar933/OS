#include "osm.h"
#include <sys/time.h>
#include <iostream>


/* Time measurement function for a simple arithmetic operation.
   returns time in nano-seconds upon success,
   and -1 upon failure.
   */
double osm_operation_time(unsigned int iterations)
{
	if (iterations == 0)
	{
		return -1;
	}
	struct timeval start, end;
	double x = 0;
	gettimeofday(&start, nullptr);
	for (unsigned int i = 0; i < iterations; i++)
	{ // loop unrolling: (5 operations instead of 1)
		x += 1;
		x += 1;
		x += 1;
		x += 1;
		x += 1;
	}
	gettimeofday(&end, nullptr);
	unsigned int start_nano = start.tv_sec * 1000000000 + start.tv_usec * 1000;
	unsigned int end_nano = end.tv_sec * 1000000000 + end.tv_usec * 1000;
	return end_nano - start_nano;
}


void empty_function()
{

}

/* Time measurement function for an empty function call.
   returns time in nano-seconds upon success,
   and -1 upon failure.
   */
double osm_function_time(unsigned int iterations)
{
	if (iterations == 0)
	{
		return -1;
	}
	struct timeval start, end;
	gettimeofday(&start, nullptr);
	for (unsigned int i = 0; i < iterations; i++)
	{
		empty_function();
		empty_function();
		empty_function();
		empty_function();
		empty_function();
	}
	gettimeofday(&end, nullptr);
	unsigned int start_nano = start.tv_sec * 1000000000 + start.tv_usec * 1000;
	unsigned int end_nano = end.tv_sec * 1000000000 + end.tv_usec * 1000;
	return end_nano - start_nano;
}


/* Time measurement function for an empty trap into the operating system.
   returns time in nano-seconds upon success,
   and -1 upon failure.
   */
double osm_syscall_time(unsigned int iterations)
{

	if (iterations == 0)
	{
		return -1;
	}
	struct timeval start, end;

	gettimeofday(&start, nullptr);
	for (unsigned int i = 0; i < iterations; i++)
	{
		// loop unrolling:
		OSM_NULLSYSCALL;
		OSM_NULLSYSCALL;
		OSM_NULLSYSCALL;
		OSM_NULLSYSCALL;
		OSM_NULLSYSCALL;
	}
	gettimeofday(&end, nullptr);
	unsigned int start_nano = start.tv_sec * 1000000000 + start.tv_usec * 1000;
	unsigned int end_nano = end.tv_sec * 1000000000 + end.tv_usec * 1000;
	return end_nano - start_nano;
}

